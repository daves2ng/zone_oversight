#!/bin/bash

# Define the bank code and name variables
MASTER="X.X.X.X"
WORKER1=""
BANK_CODE="BBB"
BANK_NAME="CCC"
TM_IP="X.X.X.X"
TM_PORT="AAA"
DB_IP="X.X.X.X"
DB_PORT="AAA"
DBUSER="DDDDD"
DBPASS='XXXXXXXXXXXXXXXXX'
PROMETHEUS_SERVER="X.X.X.X"
BLACKBOX_SERVER="X.X.X.X"

# Export variables for substitution
export MASTER WORKER1 BANK_CODE BANK_NAME TM_IP TM_PORT DB_IP DB_PORT DBUSER DBPASS PROMETHEUS_SERVER BLACKBOX_SERVER

# Generate `prometheus.yml` by replacing placeholders with actual values from `prometheus-template.yml`
envsubst < dependencies/prometheus-template.yml > prometheus/prometheus.yml

# Generate `transaction_metrics.collector.yml` from the template file
envsubst < dependencies/template_transaction_metrics.yml > sql_exporter/collectors/transaction_metrics.yml

# Generate `transaction_metrics.collector.yml` from the template file
envsubst < dependencies/template-blackbox.yml > prometheus/blackbox_targets.yml

# Generate `transaction_metrics.collector.yml` from the template file
envsubst < dependencies/template-sql.yml > sql_exporter/sql_exporter.yml

# Generate `haproxy.cfg` from the template file
envsubst < dependencies/template-haproxy.txt > haproxy/haproxy.cfg

# Generate `datasource.yml` from the template file
envsubst < dependencies/template-datasource.yml > grafana/provisioning/datasources/datasource.yml


#Set Permissions for Prometheus and Grafana
chown 1000:1000 prometheus/
chown 1000:1000 prometheus/*
chown 1000:1000 grafana/
chown 1000:1000 grafana/*
chown 1000:1000 grafana/*/*
chown 1000:1000 grafana/*/*/*
chown 1000:1000 sql_exporter/
chown 1000:1000 sql_exporter/*
chown 1000:1000 haproxy/
chown 1000:1000 haproxy/*
chmod 777 prometheus/
chmod 777 prometheus/*
chmod 777 grafana/
chmod 777 grafana/*
chmod 777 grafana/*/*
chmod 777 grafana/*/*/*
chmod 755 sql_exporter/
chmod 755 sql_exporter/*
chmod 755 haproxy/
chmod 755 haproxy/*

echo "Permissions granted to Prometheus and Grafana Folders"

# Perform additional cleanup to remove empty targets
sed -i '/^ *-\s*""/d' prometheus/prometheus.yml  # Remove any empty targets that may result

# Confirm completion
echo "Config Files generated with BANK_CODE=${BANK_CODE} BANK_NAME=${BANK_NAME} MASTER=${MASTER} WORKER1=${WORKER1} TM_IP=${TM_IP} TM_PORT=${TM_PORT} DB_IP=${DB_IP} DB_PORT=${DB_PORT} DBUSER=${DBUSER} DBPASS=XXXXXXXXXXXXXX PROMETHEUS_SERVER=${PROMETHEUS_SERVER} BLACKBOX_SERVER=${BLACKBOX_SERVER}"
